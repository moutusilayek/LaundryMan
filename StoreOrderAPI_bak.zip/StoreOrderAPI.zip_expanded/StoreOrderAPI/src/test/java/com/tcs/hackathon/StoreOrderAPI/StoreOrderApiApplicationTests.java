package com.tcs.hackathon.StoreOrderAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreOrderApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
