package com.tcs.hackathon.StoreOrderAPI.model.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.RowMapper;


public class StoreOrderReference implements RowMapper {
	
	private int filiNumber;
	private LocalDateTime deliveryDateTime;
	private int aflsNumber;
	private int  orderNumber;
	private int ovenNumber;
	
	
	public StoreOrderReference() {
		
	}


	public int getFiliNumber() {
		return filiNumber;
	}


	public void setFiliNumber(int filiNumber) {
		this.filiNumber = filiNumber;
	}


	public LocalDateTime getDeliveryDateTime() {
		return deliveryDateTime;
	}


	public void setDeliveryDateTime(LocalDateTime deliveryDateTime) {
		this.deliveryDateTime = deliveryDateTime;
	}


	public int getAflsNumber() {
		return aflsNumber;
	}


	public void setAflsNumber(int aflsNumber) {
		this.aflsNumber = aflsNumber;
	}


	public int getOrderNumber() {
		return orderNumber;
	}


	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}


	public int getOvenNumber() {
		return ovenNumber;
	}


	public void setOvenNumber(int ovenNumber) {
		this.ovenNumber = ovenNumber;
	}


	@Override
	@Bean
	public  Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		StoreOrderReference fior=new StoreOrderReference();
		if(rs.getString("AFMO_AFLEVERDATUM_TIJD").length()==21) {			
			fior.setDeliveryDateTime(LocalDateTime.parse(rs.getString("AFMO_AFLEVERDATUM_TIJD").concat("00") , DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
		}else if(rs.getString("AFMO_AFLEVERDATUM_TIJD").length()==22){
			
			fior.setDeliveryDateTime(LocalDateTime.parse(rs.getString("AFMO_AFLEVERDATUM_TIJD").concat("0") , DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
		}		
		
		fior.setAflsNumber(rs.getInt("AFLS_NUMMER"));
		fior.setFiliNumber(rs.getInt("FILI_NUMMER"));
		fior.setOrderNumber(rs.getInt("ORDER_NUMMER"));
		fior.setOvenNumber(rs.getInt("OVZE_NUMMER"));
		return fior;
	}
	
	
	
	
	
	
	
	
	
	
	

}
