package com.tcs.hackathon.StoreOrderAPI.controller;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.hackathon.StoreOrderAPI.model.model.StoreOrderReference;

import com.tcs.hackathon.StoreOrderAPI.service.StoreOrderService;

@RestController
public class Controller {
	 
	 @Autowired
	 StoreOrderService service;
	 
	
	
		@RequestMapping(method=RequestMethod.POST, value="/store-order-reference" , consumes = MediaType.APPLICATION_JSON_VALUE )
		public ResponseEntity addStoreOrder(@RequestBody StoreOrderReference fior) {
			Map map=service.addStoreOrder(fior);
			
			return new ResponseEntity(map.get("message"),HttpStatus.valueOf(Integer.parseInt(map.get("status").toString())));		
		}
		
		@RequestMapping(value="/store-order-reference/{filiNumber}/{deliveryDateTime}/{aflsnummber}/{ovzeNumber}" ,method=RequestMethod.PATCH, consumes = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity updateStoreOrder(@RequestBody StoreOrderReference fior, @PathVariable Map<String,String> varMap ){			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			LocalDateTime dateTime = LocalDateTime.parse(varMap.get("deliveryDateTime"), formatter);			
		    fior.setDeliveryDateTime(dateTime);
		    System.out.println("dateTime"+dateTime);
			fior.setFiliNumber(Integer.parseInt(varMap.get("filiNumber")));	
			fior.setAflsNumber(Integer.parseInt(varMap.get("aflsnummber")));
			fior.setOvenNumber(Integer.parseInt(varMap.get("ovzeNumber")));
			Map map=service.updateStoreOrder(fior);
			return new ResponseEntity(map.get("message"),HttpStatus.valueOf(Integer.parseInt(map.get("status").toString())));	
		}
		
		
		@RequestMapping(value="/store-order-reference/{filiNumber}/{deliveryDateTime}/{aflsnummber}/{ovzeNumber}",method=RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity deleteStoreOrder(@PathVariable Map<String,String> varMap) {			
			StoreOrderReference fior=new StoreOrderReference();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			LocalDateTime dateTime = LocalDateTime.parse(varMap.get("deliveryDateTime"), formatter);
			System.out.println("dateTime"+dateTime);
		    fior.setDeliveryDateTime(dateTime);
			fior.setFiliNumber(Integer.parseInt(varMap.get("filiNumber")));	
			fior.setAflsNumber(Integer.parseInt(varMap.get("aflsnummber")));
			fior.setOvenNumber(Integer.parseInt(varMap.get("ovzeNumber")));		   
			Map map=service.deleteStoreOrder(fior);		    
			return new ResponseEntity(map.get("message"),HttpStatus.valueOf(Integer.parseInt(map.get("status").toString())));
			
		}
		
		
		@RequestMapping(value="/store-order-reference" , produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity getStoreOrder(@RequestBody(required = false) StoreOrderReference fior) {
			List<StoreOrderReference> list=(List) service.getStoreOrder(fior);
			return new ResponseEntity(list,HttpStatus.valueOf(200));	
		}
	 
		
		@RequestMapping(value="/store-order-reference" , produces = MediaType.APPLICATION_JSON_VALUE , method=RequestMethod.GET)
		public ResponseEntity getStoreOrdersByParam(@RequestParam(required=false) Integer filiNumber , @RequestParam(required=false) Integer aflsNumber , @RequestParam(required=false) String deliveryDateTime ) {
			StoreOrderReference fior =new StoreOrderReference();
			if(null!=filiNumber && filiNumber>0) {
		    	  fior.setFiliNumber(filiNumber);
		      }
			
			 if(null!=aflsNumber && aflsNumber>0) {
		    	  fior.setAflsNumber(aflsNumber);
		      }
			 
			 if(null!=deliveryDateTime) {
				 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					LocalDateTime dateTime = LocalDateTime.parse(deliveryDateTime, formatter);					
				    fior.setDeliveryDateTime(dateTime);
			 }
			List<StoreOrderReference> list=(List) service.getStoreOrdersByParam(fior);
			return new ResponseEntity(list,HttpStatus.valueOf(200));	
		}
	
}
