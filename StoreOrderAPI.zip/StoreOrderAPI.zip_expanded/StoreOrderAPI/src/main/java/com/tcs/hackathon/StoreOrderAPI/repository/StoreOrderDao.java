package com.tcs.hackathon.StoreOrderAPI.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import com.tcs.hackathon.StoreOrderAPI.model.model.StoreOrderReference;


@Repository
public class StoreOrderDao {
	
	
	@Autowired
	  DataSource dataSource;

	
	 @Autowired
	    JdbcTemplate jdbcTemplate;
	
	 
	
	@Transactional
	public int addStoreOrder(StoreOrderReference fior) {
		
		int statusCode=0;
		String[] columns = {"FILI_NUMMER","AFMO_AFLEVERDATUM_TIJD", "AFLS_NUMMER", "OVZE_NUMMER", "ORDER_NUMMER"};
		try {
		SimpleJdbcInsert simpleJdbcInsert = 
				new SimpleJdbcInsert(dataSource)
				.usingColumns(columns)
				.withTableName("dbo.RSET_FILI_ORDER_REFERENTIE");
		
		Map<String, Object> parameters = new HashMap<String, Object>();
	    parameters.put("FILI_NUMMER", fior.getFiliNumber());
	    parameters.put("AFMO_AFLEVERDATUM_TIJD", fior.getDeliveryDateTime());
	    parameters.put("AFLS_NUMMER", fior.getAflsNumber());	    
	    parameters.put("OVZE_NUMMER", fior.getOvenNumber());
	    parameters.put("ORDER_NUMMER", fior.getOrderNumber());
	    System.out.println("rows" +" fior.getOrderNumber()" + fior.getOrderNumber() + "fior.getStoreNumber()" + fior.getFiliNumber() + "AFMO_AFLEVERDATUM_TIJD" + fior.getDeliveryDateTime() + "fior.afls()" + fior.getAflsNumber() + "OVZE_NUMMER"+ fior.getOvenNumber());
	     int rows=simpleJdbcInsert.execute(parameters);
	    
	     if(rows>0) {
	    	 statusCode=200;
	     }else {
			 statusCode=500;
		 }
	     System.out.println("statusCode" + statusCode);
		}catch(Exception ex) {			 
			statusCode=500;
			ex.printStackTrace();
			System.out.println("in eexception statusCode" + ex);
		}
		return statusCode;
  		
	}
	
	@Transactional
	public int updateStoreOrder(StoreOrderReference fior) {
		int statusCode=0;
		try {
		String sql="UPDATE [dbo].[RSET_FILI_ORDER_REFERENTIE] SET [ORDER_NUMMER] = ? WHERE  [FILI_NUMMER]=? and [AFMO_AFLEVERDATUM_TIJD] = ? and [AFLS_NUMMER]=? and [OVZE_NUMMER] =?";
		 int rows=jdbcTemplate.update(sql, fior.getOrderNumber() , fior.getFiliNumber() , fior.getDeliveryDateTime(), fior.getAflsNumber(), fior.getOvenNumber());
		 
		 if(rows>0) {
			 statusCode=200;
		 }else {
			 statusCode=500;
		 }
		
		}catch(Exception ex) {
			statusCode=500;
		}
		return statusCode;
	}
	
	
	@Transactional
	public int deleteStoreOrder(StoreOrderReference fior) {	
		int statusCode=0;
		try {
		String sql="DELETE FROM dbo.RSET_FILI_ORDER_REFERENTIE WHERE  FILI_NUMMER=? and AFMO_AFLEVERDATUM_TIJD = ? and AFLS_NUMMER=? and OVZE_NUMMER=?";
		int rows=jdbcTemplate.update(sql,  fior.getFiliNumber() , fior.getDeliveryDateTime(), fior.getAflsNumber(), fior.getOvenNumber());	
		System.out.println("rows"+ rows +" fior.getFiliNumber()" + fior.getFiliNumber() + "fior.getStoreNumber()" + fior.getFiliNumber() + "AFMO_AFLEVERDATUM_TIJD" + fior.getDeliveryDateTime() + "fior.afls()" + fior.getAflsNumber() + "OVZE_NUMMER"+ fior.getOvenNumber());
		if(rows>0) {
			 statusCode=200;
		 }else {
			 statusCode=500;
		 }
		
		}catch(Exception e) {
			e.printStackTrace();
			statusCode=500;
		}
		
		return statusCode;
		}	
	
	
	public List getStoreOrder(StoreOrderReference storeOrder) {
		  String sql =
		  "select * from  dbo.RSET_FILI_ORDER_REFERENTIE"; 	
		   List<StoreOrderReference> fior= jdbcTemplate.query(sql, new StoreOrderReference() );
		   
		   fior.forEach(s->System.out.println(s.getDeliveryDateTime()));
		   return fior;
	}
	
	public List<StoreOrderReference> getStoreOrdersByParam(StoreOrderReference fior) {
		StringBuilder sqlQuery = new StringBuilder ("select TOP 50 * from  dbo.RSET_FILI_ORDER_REFERENTIE where 1=1 ");
		 List queryArgs = new ArrayList();
		 
		 if(fior.getFiliNumber()>0){
		       sqlQuery.append("And FILI_NUMMER=? ");
		       queryArgs.add(fior.getFiliNumber());
		    }
		 
		 if(fior.getAflsNumber()>0){
		       sqlQuery.append("And AFLS_NUMMER=? ");
		       queryArgs.add(fior.getAflsNumber());
		    }
		 
		 
		 if(null!=fior.getDeliveryDateTime()){
		       sqlQuery.append("And AFMO_AFLEVERDATUM_TIJD=? ");
		       queryArgs.add(fior.getDeliveryDateTime());
		    }
		 
		 if(fior.getOvenNumber()>0){
		       sqlQuery.append("And OVZE_NUMMER=? ");
		       queryArgs.add(fior.getOvenNumber());
		    }
		 
		
		
		 Object[] preparedStatementArgs = new Object[queryArgs.size()];
		 for(int i = 0; i < preparedStatementArgs.length; i++){
		        preparedStatementArgs[i] = queryArgs.get(i);
		    }
		 
		 
		 
		 return this.jdbcTemplate.query(sqlQuery.toString(),
				    preparedStatementArgs, new StoreOrderReference());
				   
		
	}
	
	

}
