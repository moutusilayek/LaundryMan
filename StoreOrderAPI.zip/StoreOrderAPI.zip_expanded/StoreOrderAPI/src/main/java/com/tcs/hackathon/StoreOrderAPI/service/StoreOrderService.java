package com.tcs.hackathon.StoreOrderAPI.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tcs.hackathon.StoreOrderAPI.model.model.StoreOrderReference;
import com.tcs.hackathon.StoreOrderAPI.repository.StoreOrderDao;

@Service
public class StoreOrderService {
	
	
	
	@Autowired
	StoreOrderDao dao;
	
	
	public Map<Object,Object> addStoreOrder(StoreOrderReference fior) {
	     Map<Object,Object> map=new HashMap<Object,Object>();
	     int status=0;
	     if(checkData(fior)) {
		    status= dao.addStoreOrder(fior);
		   if(status==200) {
				map.put("status", status);
				map.put("message", "Store order added successfully");		
			}else {
				map.put("status", status);
				map.put("message", "Store order insertion  failed");
			}
	     }else {
	    	 map.put("status", 500);
	    	 map.put("message", "Data validation failed");
	     }	     
	     return map;
	  		
	}
	
	
	public Map<Object,Object> updateStoreOrder(StoreOrderReference fior) {
		Map<Object,Object> map=new HashMap<Object,Object>();
	     int status=0;
	     if(checkData(fior)) {
			  status= dao.updateStoreOrder(fior);	
			  map.put("status", status);
			  if(status==200) {				
					map.put("message", "Store order  updated successfully");		
				}else {				
					map.put("message", "Store order updation  failed");
				} 
	     }else {
	    	 map.put("status", 500);
			 map.put("message", "Data validation failed");
	     }	     
	     return map;	  		
	}
	
	
	
	public Map<Object,Object> deleteStoreOrder(StoreOrderReference fior) {
		Map<Object,Object> map=new HashMap<Object,Object>();
	     int status=0;		
	     if(checkData(fior)) {
	    	 status= dao.deleteStoreOrder(fior);
			  map.put("status", status);
			if(status==200) {			
				map.put("message", "Store order  deleted successfully");		
			}else {			
				map.put("message", "store order deletion  failed");
			} 
	     }else {
	    	 map.put("status", 500);
			 map.put("message", "Data validation failed");
	     }				
		return map;	  	
	}
	
	public List<StoreOrderReference> getStoreOrdersByParam(StoreOrderReference fior) {
		return dao.getStoreOrdersByParam(fior);
	  	
	}
	
	public List<StoreOrderReference> getStoreOrder(StoreOrderReference fior) {
		return dao.getStoreOrder(fior);
	  	
	}
	
	 
	 private boolean checkData(StoreOrderReference fior) {	
		 System.out.println("fior.getFiliNumber()"+fior.getFiliNumber() + "fior.getAflsNumber()"+fior.getAflsNumber() + " fior.getOvenNumber()"+ fior.getOvenNumber());
			if(fior.getFiliNumber()>0 && fior.getAflsNumber()>0 && fior.getOvenNumber()>0 ) {				
				return true;
			}
			return false;
		}
	
	
	

}
