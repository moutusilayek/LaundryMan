package com.tcs.hackathon.StoreExclusionAPI.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.tcs.hackathon.StoreExclusionAPI.model.StoreLogisticalGroupExclusion;


@Repository
public class StoreExclusionRepository {

	@Autowired
	  DataSource dataSource;

	
	 @Autowired
	    JdbcTemplate jdbcTemplate;
	
	public int addStoreExclusion(StoreLogisticalGroupExclusion aflu) {
		int statusCode=0;
		UUID uuid = UUID.randomUUID();
		String[] columns = {"FILI_NUMMER","AFLS_NUMMER", "AFLEVERDATUM_TIJD", "LGRP_NUMMER"};
		
		try {
		SimpleJdbcInsert simpleJdbcInsert = 
				new SimpleJdbcInsert(dataSource)
				.usingColumns(columns)
				.withTableName("DBO.RSET_AFMO_LGRP_UITSLUITING");
		
		Map<String, Object> parameters = new HashMap<String, Object>();
	    parameters.put("FILI_NUMMER", aflu.getFiliNumber());
	    parameters.put("AFLS_NUMMER", aflu.getAflsNumber());
	    parameters.put("AFLEVERDATUM_TIJD", aflu.getDeliveryDateTime());	    
	    parameters.put("LGRP_NUMMER", aflu.getLrgpNumber());
	    	 
	     int rows=simpleJdbcInsert.execute(parameters);
	     System.out.println("rows"+ rows +" fior.getFiliNumber()" + aflu.getFiliNumber() + "fior.getStoreNumber()" + aflu.getFiliNumber() + "AFMO_AFLEVERDATUM_TIJD" + aflu.getDeliveryDateTime() + "fior.afls()" + aflu.getAflsNumber() + "OVZE_NUMMER"+ aflu.getLrgpNumber());
	     if(rows>0) {
	    	 statusCode=200;
	     }else {
	    	 statusCode=500;
	     }
	    
		}catch(Exception ex) {
			ex.printStackTrace();
			statusCode=500;
		}
		return statusCode;
		
	}
	
	
	
	// this method is not required as per the document. Will be implemented in case required in future
	public int updateStoreExclusion(StoreLogisticalGroupExclusion aflu) {
		int statusCode=0;
		
		return statusCode;
	}
	
	
	
	public int deleteStoreExclusion(StoreLogisticalGroupExclusion aflu) {
		int statusCode=0;
		try {
		String sql="delete from DBO.RSET_AFMO_LGRP_UITSLUITING where FILI_NUMMER=? and AFLS_NUMMER=? and AFLEVERDATUM_TIJD=? and LGRP_NUMMER=?";
		int rows= jdbcTemplate.update(sql,  aflu.getFiliNumber() , aflu.getAflsNumber(), aflu.getDeliveryDateTime() , aflu.getLrgpNumber());	
		if(rows>0) {
			statusCode=200;
		}	else {
			statusCode=500;
		}
		}catch (Exception ex){
			statusCode=500;
		}
		return statusCode;
	}
	
	
	public List getStoreOrder(StoreLogisticalGroupExclusion storeOrder) {
		  String sql ="select * from DBO.RSET_AFMO_LGRP_UITSLUITING"; 
		  List<StoreLogisticalGroupExclusion> aflu=new ArrayList();
		  try {
			  aflu= jdbcTemplate.query(sql, new StoreLogisticalGroupExclusion() );
			  System.out.println("query executes"+aflu);
			 
			  
		  }catch(Exception ex) {
			  ex.printStackTrace();			  
		  }
		  return aflu;   
	}
}
