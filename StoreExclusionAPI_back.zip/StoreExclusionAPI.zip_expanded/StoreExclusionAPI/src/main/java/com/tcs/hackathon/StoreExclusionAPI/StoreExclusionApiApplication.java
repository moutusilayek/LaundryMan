package com.tcs.hackathon.StoreExclusionAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StoreExclusionApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoreExclusionApiApplication.class, args);
	}

}
