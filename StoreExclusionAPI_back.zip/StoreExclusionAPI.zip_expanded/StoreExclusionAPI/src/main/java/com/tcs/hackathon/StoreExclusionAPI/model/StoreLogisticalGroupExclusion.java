package com.tcs.hackathon.StoreExclusionAPI.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.jdbc.core.RowMapper;

public class StoreLogisticalGroupExclusion implements RowMapper {

	private int filiNumber;
	private LocalDateTime deliveryDateTime;
	private int aflsNumber;
	private int  lrgpNumber;
	
	public int getFiliNumber() {
		return filiNumber;
	}
	public void setFiliNumber(int filiNumber) {
		this.filiNumber = filiNumber;
	}
	public LocalDateTime getDeliveryDateTime() {
		return deliveryDateTime;
	}
	public void setDeliveryDateTime(LocalDateTime deliveryDateTime) {
		this.deliveryDateTime = deliveryDateTime;
	}
	public int getAflsNumber() {
		return aflsNumber;
	}
	public void setAflsNumber(int aflsNumber) {
		this.aflsNumber = aflsNumber;
	}
	public int getLrgpNumber() {
		return lrgpNumber;
	}
	public void setLrgpNumber(int lrgpNumber) {
		this.lrgpNumber = lrgpNumber;
	}
	
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		StoreLogisticalGroupExclusion aflu=new StoreLogisticalGroupExclusion();
		aflu.setFiliNumber(rs.getInt("FILI_NUMMER"));
		aflu.setAflsNumber(rs.getInt("AFLS_NUMMER"));
		aflu.setLrgpNumber(rs.getInt("LGRP_NUMMER"));
		//aflu.setDeliveryDateTime(rs.getString("AFLEVERDATUM_TIJD"));
		if(rs.getString("AFLEVERDATUM_TIJD").length()==21) {			
			aflu.setDeliveryDateTime(LocalDateTime.parse(rs.getString("AFLEVERDATUM_TIJD").concat("00") , DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
		}else if(rs.getString("AFLEVERDATUM_TIJD").length()==22){
			
			aflu.setDeliveryDateTime(LocalDateTime.parse(rs.getString("AFLEVERDATUM_TIJD").concat("0") , DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
		}
		return aflu;
	}
	
	
	
}
