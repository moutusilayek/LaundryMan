package com.tcs.hackathon.StoreExclusionAPI.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.hackathon.StoreExclusionAPI.model.StoreLogisticalGroupExclusion;
import com.tcs.hackathon.StoreExclusionAPI.repository.StoreExclusionRepository;


@Service
public class StoreExclusionService {
	
	
	@Autowired
	StoreExclusionRepository repo;


	public Map addStoreExclusion(StoreLogisticalGroupExclusion aflu) {	
		Map map=new HashMap();
		if(checkData(aflu)) {
	      int status= repo.addStoreExclusion(aflu);
	        map.put("status", status);
	       if(status==200) {			
			map.put("message", "Store exclusion added successfully");		
	       }else {
			map.put("message", "Store exclusion addition failed");
	       }
		   }else {
	    	map.put("status", 500);
			map.put("message", "Data validation failed");
	     }
	    return map;
	}
	
	
	public Map<Object,Object> updateStoreExclusion(StoreLogisticalGroupExclusion aflu) {
		Map<Object,Object> map=new HashMap<Object,Object>();
		if(checkData(aflu)) {
		  int status= repo.updateStoreExclusion(aflu);
		  map.put("status", status);
		  if(status==200) {				
				map.put("message", "Store exclusion updated successfully");		
			}else {				
				map.put("message", "Store exclusion updation failed");
			}
		}else {
	    	 map.put("status", 500);
			 map.put("message", "Data validation failed");
	     }
		    return map;
	}
	
	
	
	public Map<Object,Object> deleteStoreExclusion(StoreLogisticalGroupExclusion aflu) {					
		Map<Object,Object> map=new HashMap<Object,Object>();
		if(checkData(aflu)) {
			int status= repo.deleteStoreExclusion(aflu);
			 map.put("status", status);
			if(status==200) {			
				map.put("message", "Store exclusion deleted successfully");		
			}else {
				
				map.put("message", "Store exclusion deletion failed");
			}
		}else {
	    	 map.put("status", 500);
			 map.put("message", "Data validation failed");
	     }
		 
	    return map;
	}
	
	
	
	
	public List getStoreExclusion(StoreLogisticalGroupExclusion aflu) {			
		return repo.getStoreOrder(aflu);	
	}
	
	
	
	
	 private boolean checkData(StoreLogisticalGroupExclusion aflu) {	
		 System.out.println("fior.getFiliNumber()"+aflu.getFiliNumber() + "fior.getAflsNumber()"+aflu.getAflsNumber() + " fior.getLrgpNumber()"+ aflu.getLrgpNumber());
			if(aflu.getFiliNumber()>0 && aflu.getAflsNumber()>0 && aflu.getLrgpNumber()>0 ) {				
				return true;
			}
			return false;
		}
}
