package com.tcs.hackathon.StoreExclusionAPI.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.tcs.hackathon.StoreExclusionAPI.model.StoreLogisticalGroupExclusion;
import com.tcs.hackathon.StoreExclusionAPI.service.StoreExclusionService;




@RestController
public class StoreExclusionController {

	@Autowired
	StoreExclusionService service;
	
	@RequestMapping(value="/store-logistical-group-exclusion" , method=RequestMethod.POST , consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity insertInAFLU(@RequestBody StoreLogisticalGroupExclusion aflu  ) {
		
		Map map=service.addStoreExclusion(aflu);
		
		return new ResponseEntity(map.get("message").toString(),HttpStatus.valueOf(Integer.parseInt(map.get("status").toString())));		
	}
	

	
	
	
	@RequestMapping(value="/store-logistical-group-exclusion/{filiNumber}/{aflsnummber}/{deliveryDateTime}/{lgrpNumber}" ,method=RequestMethod.DELETE, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity deleteFromAfLU(@RequestBody(required=false) StoreLogisticalGroupExclusion aflu, @PathVariable Map<String,String> varMap) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		LocalDateTime dateTime = LocalDateTime.parse(varMap.get("deliveryDateTime"), formatter);
		System.out.println("dateTime"+dateTime);	    
		aflu.setDeliveryDateTime(dateTime);
		aflu.setFiliNumber(Integer.parseInt(varMap.get("filiNumber")));	
		aflu.setAflsNumber(Integer.parseInt(varMap.get("aflsnummber")));
		aflu.setLrgpNumber(Integer.parseInt(varMap.get("lgrpNumber")));
		
		Map map=service.deleteStoreExclusion(aflu);
		return new ResponseEntity(map.get("message").toString(),HttpStatus.valueOf(Integer.parseInt(map.get("status").toString())));		
	}
	
	
	@RequestMapping(value="/store-logistical-group-exclusion" ,method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity getStoreOrder(@RequestBody(required = false) StoreLogisticalGroupExclusion aflu) {
		List<StoreLogisticalGroupExclusion> list=(List<StoreLogisticalGroupExclusion>) service.getStoreExclusion(aflu);
		
		return new ResponseEntity(list,HttpStatus.valueOf(200));	
	}
	
	
	@RequestMapping(value="/store-logistical-group-exclusion/{filiNumber}/{aflsnummber}/{deliveryDateTime}/{lgrpNumber}" ,method=RequestMethod.PATCH, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity updateInAFLU(@RequestBody StoreLogisticalGroupExclusion aflu, @PathVariable Map<String,String> varMap) {		
		aflu.setLrgpNumber(Integer.parseInt(varMap.get("filiNumber")));
		aflu.setFiliNumber(Integer.parseInt(varMap.get("aflsnummber")));
		aflu.setAflsNumber(Integer.parseInt(varMap.get("lgrpNumber")));
		Map map= service.updateStoreExclusion(aflu);		
		return new ResponseEntity(map.get("message").toString(),HttpStatus.valueOf(Integer.parseInt(map.get("status").toString())));		
	}
}
