package com.tcs.hackathon.StoreExclusionAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreExclusionApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
